<?php
/**
 * Firebear Improved Import Module
 *
 * @category    Firebear
 * @package     Firebear_ImprovedImport
 * @copyright   Copyright (c) 2013 Firebear
 * @author      biotech (Hlupko Viktor)
 */

/**
 * Helper
 *
 * @category    Firebear
 * @package     Firebear_ImprovedImport
 */
class Firebear_ImprovedImport_Helper_Data extends Mage_Core_Helper_Abstract
{

}