<?php

class Firebear_ImprovedImport_Model_Export_Entity_Product_Type_Bundle
    extends Mage_ImportExport_Model_Export_Entity_Product_Type_Abstract
{
}
